export default{
	friends: function(){
		let friendrr = [
			{
				id:1,
				imgurl: '001.jpg',
				tip:12345,
				name:'大海无量',
				isuserid:'12344556699',
				time: new Date(),
				news:'汉字，又称中文、中国字，别称方块字，是汉语的记录符号，属于表意文字的词素音节文字。',
				
			},
			{
				id:2,
				imgurl: '002.jpg',
				tip:0,
				name:'山川',
				isuserid:'123446699',
				time:new Date(),
				news:'汉字，又称中文、中国字，别称方块字，是，属于表意文字的词素音节文字。',
				
			},
			{
				id:3,
				imgurl: '003.jpg',
				tip:12,
				name:'流水',
				isuserid:'156997744',
				time:new Date(),
				news:'汉字，称方块字，是汉语的记录符号，属于表意文字的词素音节文字。',
				
			},
			{
				id:4,
				imgurl: '004.jpg',
				tip:0,
				name:'高原',
				isuserid:'156997996',
				time:new Date(),
				news:'汉字，又称中文、中国字，别称方块字，是汉语的记录文字....',
},
{
				id:5,
				imgurl: '001.jpg',
				tip:2,
				name:'小海',
				isuserid:'699774455',
				time:new Date(),
				news:'汉字，又称中文、中国字，别称方块字，是汉语的记录符号，属于表意文字的词素音节文字。',
				
			},
			{
				id:6,
				imgurl: '002.jpg',
				tip:0,
				name:'瀑布',
				isuserid:'136987455',
				time:new Date(),
				news:'汉字，又称中文、中国字，别称方块字，是，属于表意文字的词素音节文字。',
				
			},
			{
				id:7,
				imgurl: '003.jpg',
				tip:12,
				name:'溪流',
				isuserid:'1333698454',
				time:new Date(),
				news:'汉字，称方块字，是汉语的记录符号，属于表意文字的词素音节文字。',
				
			},
			{
				id:8,
				imgurl: '004.jpg',
				tip:0,
				name:'黄山',
				isuserid:'6666',
				time:new Date(),
				news:'汉字，又称中文、中国字，别称方块字，是汉语的记录文字....',
},
{
				id:9,
				imgurl: '004.jpg',
				tip:0,
				name:'黄山',
				isuserid:'6666',
				time:new Date(),
				news:'汉字，又称中文、中国字，别称方块字，是汉语的记录文字....',
},
{
				id:10,
				imgurl: '004.jpg',
				tip:0,
				name:'黄山',
				isuserid:'6666',
				time:new Date(),
				news:'汉字，又称中文、中国字，别称方块字，是汉语的记录文字....',
},
{
				id:11,
				imgurl: '004.jpg',
				tip:0,
				name:'黄山',
				isuserid:'6666',
				time:new Date(),
				news:'汉字，又称中文、中国字，别称方块字，是汉语的记录文字....',
},
{
				id:12,
				imgurl: '004.jpg',
				tip:0,
				name:'黄山',
				isuserid:'6666',
				time:new Date(),
				news:'汉字，又称中文、中国字，别称方块字，是汉语的记录文字....',
},
{
				id:13,
				imgurl: '004.jpg',
				tip:0,
				name:'黄山',
				isuserid:'6666',
				time:new Date(),
				news:'汉字，又称中文、中国字，别称方块字，是汉语的记录文字....',
},
			
		]
		return friendrr;
	},
	//好友表
	isFriends: function(){
		
		let isFriend = [
			{	
				userid:1,
				friend:2,
			},
			{
				userid:1,
				friend:5,
			},
			{
				userid:1,
				friend:6,
			},
			{
				userid:1,
				friend:8,
			},
			
		]
		return isFriend
	},
}