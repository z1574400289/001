<template>
  <view class="share-item">
    <text class="share-content">{{ shareData.content }}</text>
    <view class="action-buttons">
      <button @click="like">点赞（{{ shareData.likes }}）</button>
      <button @click="comment">评论（{{ shareData.comments.length }}）</button>
      <button @click="share">分享（{{ shareData.shareCount }}）</button>
    </view>
  </view>
</template>

<script>
export default {
  props: {
    shareData: {
      type: Object,
      required: true
    }
  },
  methods: {
    like() {
      // 实际应用需发送网络请求到后端更新点赞数，这里简单模拟数据更新
      this.shareData.likes++;
      console.log('点赞成功');
    },
    comment() {
      console.log('进入评论页面逻辑，可后续完善');
      // 此处可以添加跳转到评论页面等逻辑，比如使用 uni.navigateTo 等方法
    },
    share() {
      // 实际需调用平台分享 API 实现分享功能，这里简单模拟数据更新
      this.shareData.shareCount++;
      console.log('分享成功');
    }
  }
};
</script>

<style lang="scss">
.share-item {
  border: 1px solid #ccc;
  padding: 10px;
  margin-bottom: 10px;

.share-content {
    margin-bottom: 5px;
  }

.action-buttons {
    display: flex;
    justify-content: space-around;
  }
}
</style>