<template>
  <view class="chat-page">
    <view class="header-section">
      <image :src="friendAvatar" class="friend-avatar" />
      <text class="friend-nickname">{{ friendNickname }}</text>
    </view>
    <view class="message-list">
      <!-- 这里用于展示聊天消息列表 -->
      <view
        v-for="(message, index) in messageList"
        :key="index"
        class="message-item"
        :class="{
          self-message: message.isSelf,
          other-message:!message.isSelf
        }"
      >
        <image :src="message.fromAvatar" class="message-avatar" />
        <text class="message-nickname">{{ message.fromNickname }}</text>
        <text class="message-content">{{ message.content }}</text>
      </view>
    </view>
    <view class="input-section">
      <input type="text" v-model="inputMessage" placeholder="请输入消息" @confirm="sendMessage" />
      <button @click="sendMessage">发送</button>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      friendId: "",
      friendAvatar: "", // 新增，用于存储好友头像链接
      friendNickname: "", // 新增，用于存储好友昵称
      messageList: [],
      inputMessage: "",
      // 用于标识是否正在获取新消息，避免重复请求
      isFetchingNewMessages: false,
      // 定时器标识，用于清除轮询获取新消息的定时器
      timer: null
    };
  },
  onLoad(options) {
    this.friendId = options.friendId;
    console.log("当前聊天好友ID：", this.friendId);
    // 这里调用后端接口获取好友信息（包含头像、昵称）以及聊天记录，然后初始化界面展示
    this.fetchFriendInfoAndMessages().then(() => {
      // 开始轮询获取新消息
      this.startPollingForNewMessages();
    });
  },
  beforeDestroy() {
    // 在组件销毁前，清除轮询获取新消息的定时器
    clearInterval(this.timer);
  },
  methods: {
    async fetchFriendInfoAndMessages() {
      // 模拟从后端获取好友信息（包含头像和昵称）和聊天记录数据，实际应用中需替换为真实的接口请求，例如使用uni.request等方法
      const friendInfoResponse = await Promise.resolve({
        data: {
          avatar: "https://example.com/friend-avatar.jpg", // 模拟好友头像链接，实际从后端获取
          nickname: "好友昵称" // 模拟好友昵称，实际从后端获取
        }
      });
      const messagesResponse = await Promise.resolve({
        data: [
          {
            content: "你好呀",
            isSelf: false,
            fromAvatar: "https://example.com/other-avatar.jpg", // 模拟对方头像链接，实际从后端获取每条消息对应的发送者头像
            fromNickname: "对方昵称" // 模拟对方昵称，实际从后端获取每条消息对应的发送者昵称
          }
        ]
      });
      this.friendAvatar = friendInfoResponse.data.avatar;
      this.friendNickname = friendInfoResponse.data.nickname;
      this.messageList = messagesResponse.data;
    },
    async sendMessage() {
      if (this.inputMessage.trim()!== "") {
        // 构造要发送给后端的消息数据，包含消息内容、好友ID等，实际根据后端接口要求调整
        const messageData = {
          content: this.inputMessage,
          friendId: this.friendId
        };
        try {
          // 发送消息给后端，使用uni-request模拟HTTP请求，实际根据项目情况替换
          const sendResponse = await uni.request({
            url: "https://your-backend-url/send-message", // 替换为真实后端发送消息接口地址
            method: "POST",
            data: messageData
          });
          if (sendResponse[1].statusCode === 200) {
            // 发送成功后，将自己发送的消息添加到消息列表，这里模拟后端返回的消息数据结构添加消息，实际根据后端真实返回调整
            const selfMessage = {
              content: this.inputMessage,
              isSelf: true,
              fromAvatar: "https://example.com/self-avatar.jpg", // 模拟自己头像链接，实际根据实际情况获取或配置
              fromNickname: "自己昵称" // 模拟自己昵称，实际根据实际情况填写或从用户信息获取
            };
            this.messageList.push(selfMessage);
            this.inputMessage = "";
          } else {
            console.error("消息发送失败，状态码：", sendResponse[1].statusCode);
            uni.showToast({
              title: "消息发送失败，请稍后再试",
              icon: "none"
            });
          }
        } catch (error) {
          console.error("消息发送出现异常：", error);
          uni.showToast({
            title: "消息发送出现异常，请检查网络",
            icon: "none"
          });
        }
      }
    },
    async fetchNewMessages() {
      if (!this.isFetchingNewMessages) {
        this.isFetchingNewMessages = true;
        try {
          // 从后端获取新消息，使用uni-request模拟HTTP请求，实际根据项目情况替换
          const newMessagesResponse = await uni.request({
            url: "https://your-backend-url/get-new-messages", // 替换为真实后端获取新消息接口地址
            method: "GET",
            data: {
              friendId: this.friendId
            }
          });
          if (newMessagesResponse[1].statusCode === 200) {
            const newMessages = newMessagesResponse[1].data;
            if (newMessages && newMessages.length > 0) {
              // 将获取到的新消息添加到消息列表
              this.messageList.push(...newMessages);
            }
          } else {
            console.error("获取新消息失败，状态码：", newMessagesResponse[1].statusCode);
          }
        } catch (error) {
          console.error("获取新消息出现异常：", error);
        } finally {
          this.isFetchingNewMessages = false;
        }
      }
    },
    startPollingForNewMessages() {
      // 每隔一定时间（这里设置为3秒，可根据实际情况调整）轮询获取新消息
      this.timer = setInterval(() => {
        this.fetchNewMessages();
      }, 3000);
    }
  }
};
</script>

<style lang="scss">
.chat-page {
  display: flex;
  flex-direction: column;
  height: 100vh;

.header-section {
    display: flex;
    align-items: center;
    padding: 10px;
    border-bottom: 1px solid #ccc;

  .friend-avatar {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      margin-right: 10px;
    }

  .friend-nickname {
      font-size: 16px;
      font-weight: bold;
    }
  }

.message-list {
    flex: 1;
    overflow-y: scroll;
    padding: 10px;

  .message-item {
      display: flex;
      align-items: center;
      margin-bottom: 10px;
      padding: 5px 10px;
      border-radius: 5px;

    .message-avatar {
        width: 30px;
        height: 30px;
        border-radius: 50%;
        margin-right: 5px;
      }

    .message-nickname {
        font-size: 14px;
        margin-right: 5px;
      }

    .message-content {
        font-size: 14px;
      }
    }

  .self-message {
      background-color: #0081ff;
      color: white;
      align-self: flex-end;
    }

  .other-message {
      background-color: #ccc;
      color: black;
    }
  }

.input-section {
    display: flex;
    align-items: center;
    padding: 10px;

    input {
      flex: 1;
      margin-right: 10px;
    }
  }
}
</style>