<template>
	<view class="content">
		<view class="top-bar">
			<view class="top-bar-left">
				<image src="../../static/images/img/001.jpg"></image>
			</view>
			<view class="top-bar-center">
				<image src="../../static/images/sgin/fire.png" class="logo"></image>
			</view>
			<view class="top-bar-right">
				
				<view class="search" @tap="toSearch"> <image src="../../static/images/index/search.png"></image></view>
				<view class="add"><image src="../../static/images/index/add.png"></image></view>
			</view>
		</view>
		
		<scroll-view :scroll-top="scrollTop"  scroll-y="true" class="scroll-Y" @scroll="scroll">
			<view class="friends">
				<view class="friends-list" >
					<view class="friends-list-l">
				      <text class="tip">1</text>
					  <image src="../../static/images/index/user-add.png"></image>
					</view>
					<view class="friends-list-r">
						<view class="top">
							<view class="name">好友申请</view>
							<view class="time">13：56</view>
						</view>
						<view class="news">你好，认识一下？</view>
						
					</view>
				</view>	
			</view>
			
			<view class="friends">
				
				<view class="friends-list" v-for="(item, index) in friends" :key="item.id">
					<view class="friends-list-l">
				      <text class="tip" v-if="item.tip>0">{{item.tip}}</text>
					  <image :src="item.imgurl"></image>
					</view>
					<view class="friends-list-r">
						<view class="top">
							<view class="name">{{item.name}}</view>
							<view class="time">{{changTime(item.time)}}</view>
						</view>
						<view class="news">{{item.news}}</view>
						
					</view>
				</view>	
			</view>
			
				
				
	</scroll-view>
			
			
			
					
			
	<!-- 		
		<view class="bot"> 
		
		<view class="bot-left" style="-webkit-flex: 1;flex: 1;">
			<image src="../../static/images/index/聊天@2x.png"></image>
			<view class="text">聊天</view>
		</view>
		<view class="bot-center" style="-webkit-flex: 1;flex: 1;">
			<image src="../../static/images/index/group02.png"></image>
			<view class="text" @click="goyike">yike</view>
		</view>
		<view class="bot-right" style="-webkit-flex: 1;flex: 1;">
			<image src="../../static/images/index/Group 4@2x.png"></image>
			<view class="text" @click="gopipei">匹配</view>
		</view>
		<view class="bot-04" style="-webkit-flex: 1;flex: 1;">
			<image src="../../static/images/index/Group 4@2x.png"></image>
			<view class="text" @click="gowode">我的</view>
		</view>
		</view> -->
			
			
		
		
	</view>
	
</template>

<script>
	import datas from "../../commons/js/datas.js";
	import myfun from "../../commons/js/myfun.js";
	export default {
		data() {
			return {
				friends:[],
	scrollTop: 0,
	old: {
		scrollTop: 0
	}
			}
		},
		onLoad() {
			this.getFrinds();
		},
		methods: {
			changTime: function(date){
				return myfun.dateTime(date);
			},
      goyike:function(){
        uni.navigateTo({
          url:'/pages/yike/yike'
        })
      },
      gopipei:function(){
        uni.navigateTo({
          url:'/pages/pipei/pipei'
        })
      },
      gowode:function(){
        uni.navigateTo({
          url:'/pages/wode/wode'
        })
      },
			
			getFrinds: function(){
				this.friends = datas.friends();
				for(let i=0;i< this.friends.length;i++){
				this.friends[i].imgurl='../../static/images/img/'+this.friends[i].imgurl;
				}
				console.log(this.friends);
			},
			scroll: function(e) {
				this.old.scrollTop = e.detail.scrollTop
			},
			goTop: function(e) {
				// 解决view层不同步的问题
				this.scrollTop = this.old.scrollTop
				this.$nextTick(function() {
					this.scrollTop = 0
				});
				uni.showToast({
					icon:"none",
					title:"纵向滚动 scrollTop 值已被修改为 0"
				})
			},
			toSearch: function(){
				uni.navigateTo({
					url:'/pages/search/search',
				});
			},
		}
	}
</script>


<style lang="scss">
	@import "../../commons/css/mycss.scss";
	.scroll-Y {
		height: 100%;
		padding-top: 104rpx;
		width: 100%;
		// border: 1rpx solid red;
		padding-bottom: 0rpx;
	}
	.lower-threshold {
    
  }
	.scroll-view_H {
		white-space: nowrap;
		width: 100%;
	}
	.top-bar{
		background: rgba(255, 255, 255, 0.96);
		// border-bottom: 1px solid $uni-border-color;
	}
	
	.main{
		padding-top: 104rpx;
		width: 100%;
		// border: 1rpx solid red;
        padding-bottom: $uni-spacing-col-base;
	}
	.friends-list{
		height: 96rpx;
		padding: 16rpx  $uni-spacing-col-base;
		&:active{
			background-color: $uni-bg-color-grey;
		}
		.friends-list-l{
			position: relative;
			float: left;
		
			image{
				width: 96rpx;
				height: 96rpx;
				border-radius: $uni-border-radius-base;
				background-color: $uni-color-primary;
			}
			.tip{
				position: absolute;
				z-index: 9;
				min-width: 20rpx;
				top: -8rpx;
				left: 68rpx;
				height: 36rpx;
				padding: 0 8rpx;
				background:$uni-color-warning;
				border-radius: 18rpx;
				font-size:  $uni-font-size-sm;
				color: $uni-text-color-inverse;
				line-height: 36rpx;
				text-align: center;
			}

		}
		.friends-list-r{
			padding-left: 160rpx;
			.top{
				height: 50rpx;
				.name{
					float: left;
					font-size: 36rpx;
					color: $uni-text-color;
					font-weight: 400;
					line-height: 50rpx;
				}
				.time{
					float: right;
					padding-right: 32rpx;
					font-size: $uni-font-size-sm;
					color: $uni-text-color-disable;
					line-height: 50rpx;
					// display: none;
			}}
			.news{
				font-size: $uni-font-size-base;
				color: $uni-text-color-grey;
				line-height: 40rpx;
				  overflow:hidden;
				  -webkit-line-clamp: 1;
				  display: -webkit-box;
				  -webkit-box-orient: vertical;
			}
				
			
			
		}
	}
.bot{
	display: flex;
	position: fixed;
	width: 100%;
	bottom: 2rpx;
    padding-top: 6rpx;
	padding-left: 70rpx;
	border-top: 1px solid $uni-border-color;
    height: 120rpx;
	z-index: 10;
	.bot-left{
		
		image{
			width: 56rpx;
			height: 56rpx;
		}
		.text{

			height: 28rpx;
			font-size: 20rpx;
			color: #272832;
			letter-spacing: -0.34rpx;
		}
	}
	.bot-center{
		// padding-left: ;
		image{
			width: 56rpx;
			height: 56rpx;
		}
		text{
		
			height: 28rpx;
			font-size: 20rpx;
			color: #272832;
			letter-spacing: -0.34rpx;
		}
	}
	.bot-right{
		// padding: ;
		image{
			width: 56rpx;
			height: 56rpx;
		}
		text{
		
			height: 28rpx;
			font-size: 20rpx;
			color: #272832;
			letter-spacing: -0.34rpx;
		}
	}
	.bot-04{
		// padding: ;
		image{
			width: 56rpx;
			height: 56rpx;
		}
		text{
		
			height: 28rpx;
			font-size: 20rpx;
			color: #272832;
			letter-spacing: -0.34rpx;
		}
	}
}

</style>