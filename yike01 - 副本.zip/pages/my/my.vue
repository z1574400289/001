<template>
  <view class="my-page">
    <image
      class="avatar"
      src="@/static/images/img/001.jpg"
      mode="aspectFill"
    ></image>
    <text class="nickname">用户名</text>
    <view class="dynamic-list">
      <text v-for="(dynamic, index) in dynamicList" :key="index">
        {{ dynamic }}
      </text>
    </view>
  </view>
</template>

<script>
export default {
  data() {
    return {
      dynamicList: [
        '今天发布了一条有趣的动态',
        '昨天分享了一段美好的回忆'
      ] // 模拟用户动态列表数据
    };
  }
};
</script>

<style lang="scss">
.my-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;

.avatar {
    width: 100px;
    height: 100px;
    border-radius: 50%;
    margin-bottom: 10px;
  }

.nickname {
    font-size: 18px;
    margin-bottom: 10px;
  }

.dynamic-list {
    width: 100%;
  }
}
</style>