<template>
  <view class="match-page">
    <text class="match-times">剩余匹配次数：{{ matchTimes }}</text>
    <button type="primary" @click="startMatch" :disabled="matchTimes <= 0">点击匹配</button>
  </view>
</template>

<script>
export default {
  data() {
    return {
      matchTimes: 15 // 初始匹配次数设置为15次
    };
  },
  methods: {
    startMatch() {
      // 这里简单模拟随机匹配，实际需与后端交互获取匹配用户等信息
      this.matchTimes--;
      console.log(`正在进行第${16 - this.matchTimes}次随机匹配...`);
    }
  }
};
</script>

<style lang="scss">
.match-page {
  display: flex;
  flex-direction: column;
  align-items: center;
  padding: 20px;

.match-times {
    font-size: 18px;
    margin-bottom: 20px;
  }
}
</style>