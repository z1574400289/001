<template>
	<view class="content">
	<view class="top-bar">
		<view class="search-div">
			<input type="search" placeholder="搜索用户名/id号"  class="search" placeholder-style="color:#aaa;font-weight:4000" @input="search"></input>
			<image class="search-img" src="../../static/images/search/search.png"></image>
		
		
		</view>
		<view class="top-bar-right">
			<view class="text" @tap="backOne">取消</view>
		</view>
		</view>
		<view class="main" >
			<view class="top" v-if="userarr.length>0">用户</view>
			<view class="div" v-for="(item,index) in userarr" :key="item.id">
				<view class="left"> <image class="left-img" :src="item.imgurl"></image></view>
				<view class="names">
					<view class="name"  v-html="item.name"></view>
					<view class="id" v-html="item.isuserid"></view>
				</view>
			
				<view class="right send" v-if="item.tip==1">发消息</view>
				<view class="right add" v-if="item.tip!=1">加好友</view>
			</view>

					
		
		</view>
	
	</view>
</template>

<script>
    import datas from '../../commons/js/datas.js';
	export default {
		data() {
			return {
				userarr:[],
				
			}
		},
		methods:{
			
			//获取关键词
			search:function(e){
							this.userarr=[];
							let searchval = e.detail.value;
							if(searchval.length>0){
								this.searchUser(searchval);	
							}
							
			},
			//寻找关键词匹配的用户
			searchUser:function(e){
				let arr = datas.friends();
				let exp= eval("/"+e+"/g");
				for (let i = 0; i < arr.length; i++){					
					if(arr[i].name.search(e) !=-1 || arr[i].isuserid.search(e) !=-1 ){
						this.isFriends(arr[i]);
						arr[i].imgurl='../../static/images/img/'+arr[i].imgurl;
						arr[i].name= arr[i].name.replace(exp,"<span style='color:#4AAAFF;'>"+e+"</span>");
						arr[i].isuserid= "id:"+arr[i].isuserid.replace(exp,"<span style='color:#4AAAFF;'>"+e+"</span>");
					    this.userarr.push(arr[i]);
					}
				}
			},
			//判断是否为好友
			isFriends:function(e){
				let tip = 0;
				let arr = datas.isFriends();
				for (var i = 0; i < arr.length; i++) {
					if(arr[i].friend== e.id){
						tip=1;
					}
				}
				e.tip=tip
	            // console.log(e.tip);
				
			},
			//返回上一页
			backOne: function(){
				uni.navigateBack({
					delta: 1
				});
			},
		}
	}
</script>

<style lang="scss">
	@import "../../commons/css/mycss.scss";
    .top-bar{
		
	.search-div{
		// border: 1px solid red;
		position: absolute;	
		top: 0;
		left: 0;
		box-sizing: border-box;
		padding: 14rpx 118rpx 14rpx $uni-font-size-lg;
		width: 100%;
		z-index: -1;
	}
	.search{
		padding: 0 60rpx 0 12rpx;
		height: 60rpx;
		background: $uni-bg-color-grey;
		border-radius: 10px;
		
	}
	.search-img{
		position: absolute;
		right: 130rpx;
		top: 22rpx;
		height: 40rpx;
		width: 40rpx;
	}
	.top-bar-right{
		
	}
	}
	.main{
		padding: 88rpx $uni-spacing-col-base;
		.top{
			padding-top: $uni-spacing-col-base;
			height: 86rpx;
			font-size: 44rpx;
			color: $uni-text-color;
		}
		.div{
		
			width: 100%;
			height: 80rpx;
			padding: 20rpx 0;
	      
			.left{
				image{
					float: left;
					width: 80rpx;
					height: 80rpx;
					border-radius: 20rpx;
					line-height: 80rpx;
				}
			
			}
			.names{
				float: left;
			    padding-left: $uni-spacing-col-base;
			
				.name{
					font-size: 36rpx;
					color:  $uni-text-color;
					line-height: 50rpx;	  
				}
				.id{
					height: 50rpx;
					font-size: $uni-font-size-sm;
					color: $uni-text-color;
					line-height: 28rpx;	  
				}
			}
			
			.right{
				float: right;
				// padding-right: ;
				width: 120rpx;
				height: 48rpx;		        
		       border-radius: 24rpx;
		       font-size: $uni-font-size-sm;	       
		        text-align: center;
				line-height: 48rpx;	
			    margin-top: 16rpx;
			}
			.send{
				background: $uni-color-primary;
				color: $uni-text-color;
			}
			.add{
				background: rgba(74,170,255,0.10);
				color:$uni-color-success;
			}
		}
	}
</style>
