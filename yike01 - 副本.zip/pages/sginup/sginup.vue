<template>
	<view class="content">
	<view class="top-bar">
		<view class="top-bar-left" @tap="backOne"><image src="../../static/images/common/back.png" class="back-img"></image></view>
		
	</view>
	<view class="logo"> <image  src="../../static/images/sgin/fire.png"></image></view>
	<view class="main">
		<view class="title">注册</view>
		<view class="inputs">
			<view class="inputs-div">
				<input type="text" placeholder="请取个名字" class="user" placeholder-style="color:#aaa;font-weight:4000" @input="getUser"/>
				<text class="elapsed" v-if="userelapsed">已占用</text>
				<image src="../../static/images/sgin/right.png" class="yes" v-if="isuser"></image>
			</view>
			<view class="inputs-div">
				<input type="text" placeholder="手机号码" class="phone" placeholder-style="color:#aaa;font-weight:4000" @input="isphone"/>
				<text class="elapsed" v-if="phoneelapsed">已占用</text>
				<view class="Invalid" v-if="Invalid">无效</view>
				<image src="../../static/images/sgin/right.png" class="yes" v-if="isphone"></image>
			</view>
	        <view class="inputs-div">
				<input :type="type" placeholder="这里输入密码" class="password" placeholder-style="color:#aaa;font-weight:4000" @input="getPassword"/>
				<!-- <text class="elapsed"v-if="pswelapsed">已占用</text> -->
				<image :src="lookurl" class="look" @tap="looks"></image>
			</view>
		</view>
		</view>
		
	
	<view :class="[{submit:isok},{submit1:!isok}]">注册</view>
		</view>
		
</template>

<script>
	export default {
		data() {
			return {
				type: 'password',
				isuser: true,//用户名是否可用
				isphone: true,//手机号是否可用
				look: false,//是否显示密码
				Invalid: false, //邮箱是否符合
				userelapsed: false,//用户名是否被占用
				phoneelapsed:false,
				lookurl: '../../static/images/sgin/Nlook.jpg',
				phone:'',
				isok:false,
				user:'',
				password:'',
			}
		},
		methods: {
			//密码显示隐藏方法
			looks: function(){
				if(this.look){
					this.type="password";
					this.look=!this.look;
					this.lookurl='../../static/images/sgin/Nlook.jpg';
				}else{
					this.type="text";
					this.look=!this.look;
					this.lookurl='../../static/images/sgin/look.png';
				}
			},
			//判断手机号格式是否正确
			isphone: function(e){
				this.phone=e.detail.value;
				let reg = /^([a-zA-Z]|[0-9])(\w|\-)+@[a-zA-Z0-9]+\.([a-zA-Z]{2,4})$/;
				if(this.phone.length>0){
					if(reg.test(this.phone)){
						// console.log("正确");
						// alert("邮箱正确");
						this.Invalid = false;
					}else{
						// console.log("不正确");
						// alert("邮箱不正确");
						this.Invalid = true;
					}
					
				}
				this.isOk();
			},
			//返回登录页面
			backOne: function(){
				uni.navigateBack({
					delta: 1
				});
			},
		//获取用户名
		getUser: function(e){
		this.user = e.detail.value;
		this.isOk();
		},
		//获取密码
		getPassword: function(e){
		 this.password = e.detail.value;
		 this.isOk();
		},
		//注册操作
			isOk: function(){
				if(this.isuser  && this.isphone && this.password.length>5 ){
					this.isok  =  true;
				}else{
					this.isok = false;
				}
			}
			
			
		}
	}
</script>

<style lang="scss">
	@import "../../commons/css/mycss.scss";
	@import "../../commons/css/mycss.scss";


.logo {
	text-align: center;
	image{
		 padding-top: 256rpx;
		 width: 194rpx;
		 height: 92rpx;
		 margin: 0 auto;
		 }
}
	.main{
		padding: 54rpx $uni-spacing-row-lg 120rpx;
		// width: 100%;
		
		.title{
			font-size: 56rpx;
			color: $uni-text-color;
			line-height:  80rpx;
			font-weight: 500;
			
		}
	}
.inputs{
	    padding-top:8rpx;

     .inputs-div{
		position: relative;
		.elapsed,.Invalid{
			position: absolute;
			right: 0;
			top: 40rpx;
			font-size: $uni-font-size-lg;
			color: $uni-color-warning;
			line-height: 88rpx;
		}
		.yes{
			position: absolute;
			top: 68rpx;
			right: 0;
			width: 42rpx;
			height: 32rpx;
		}
		.look{
			position: absolute;
			top: 68rpx;
			right: 0;
			width: 40rpx;
			height: 40rpx;
		}
	}
		input{
			padding-top: 40rpx;
			height: 88rpx;
			font-size: $uni-font-size-lg;
			color: $uni-text-color;
			letter-spacing: 0;
			font-weight: 500;
			line-height: 88rpx;
			border-bottom: 1px solid $uni-border-color;
		}	
	}
	
	
	
    .submit{
		margin:0 auto;
		width: 520rpx;
		height: 96rpx;
		background: $uni-color-primary;
		box-shadow: 0rpx 50rpx 32rpx -36rpx rgba(255,228,49,0.4);
		border-radius: 48rpx;
		font-size: $uni-font-size-lg;
		color: $uni-text-color;
		line-height: 96rpx;
		font-weight: 500;
		text-align: center;
	}
	.submit1{
		margin:0 auto;
		width: 520rpx;
		height: 96rpx;
		background: rgba(39,40,50,0.20);
		border-radius: 48rpx;
		font-size: $uni-font-size-lg;
		color: $uni-text-color;
		line-height: 96rpx;
		font-weight: 500;
		text-align: center;
	}
	
.tips{
	// padding-bottom: 120rpx;
	// height: 56rpx;
	float: left;
	font-size: $uni-font-size-lg;
	color: $uni-color-warning;
	line-height: 56rpx;
}


</style>

