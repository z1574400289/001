<template >
  <view class="container">
    <image class="back-img" src="../../static/images/sgin/redback-img.jpg" mode="aspectFill"></image>
    <view class="header">
      <text class="help-feedback">帮助反馈</text>
    </view>
    <view class="logo-area">
      <image class="logo" src="/static/sparkchat_logo.png"></image>
      <text class="slogan">擦出不一样的小火花</text>
    </view>
    <!-- 本机号码一键登录模块 -->
  <!--  <view v-if="loginMode === 'one-key-login'">
      <text class="phone-number">156****1073</text>
      <button @click="oneKeyLogin" class="one-key-login">本机号码一键登录</button>
      <button @click="setLoginMode('other-login')" class="other-login">其他手机号码登录</button>
    </view> -->
    <!-- 其他手机号码登录模块 -->
    <view v-if="loginMode === 'other-login'">
      <view class="input-area">
        <view class="code-input">
          <text class="code">+86</text>
          <input v-model="phoneNumber" type="number" placeholder="输入手机号"  @input="checkPhoneNumber" />
        </view>
        <button @click="goToVerifyCode" :disabled="!isPhoneNumberValid" :class="{'continue-btn-disabled':!isPhoneNumberValid, 'continue-btn': isPhoneNumberValid}" class="continue-btn">继续</button>
      </view>
    </view>
    <!-- 验证码登录模块 -->
    <view v-if="loginMode === 'verify-code-login'">
      <view class="verify-code-area">
        <text class="greeting">Hi~ 验证码是...</text>
        <view class="input-button-row">
        <input v-model="verifyCode" type="number" placeholder="输入验证码" />
        <button @click="getVerifyCode" class="get-code-btn">获取验证码</button>
        </view>
        <button @click="loginWithVerifyCode" class="login-btn">登录</button>
        <text @click="setLoginMode('password-login')">密码登录</text>
      </view>
    </view>
    <!-- 密码登录模块 -->
    <view v-if="loginMode === 'password-login'">
      <view class="password-area">
        <text class="greeting">Hi~ 密码是...</text>
        <input v-model="password" type="password" placeholder="输入密码" />
        <button @click="loginWithPassword" class="login-btn">登录</button>
        <text @click="setLoginMode('verify-code-login')">验证码登录</text>
      </view>
    </view>
    <view class="cartoon-area">
      <!-- 这里放置卡通元素的代码 -->
    </view>
  </view>
		
</template>

<script>
export default {
  data() {
    return {
      loginMode: 'other-login',
      phoneNumber: '',
      verifyCode: '',
      password: '',
      isPhoneNumberValid: false,
      countdown: 0, // 新增，用于记录获取验证码的倒计时时间
      timer: null // 新增，用于存储定时器的引用
    };
  },
  methods: {
    oneKeyLogin() {
      // 实现本机号码一键登录的逻辑
      console.log('本机号码一键登录');
    },
    setLoginMode(mode) {
      this.loginMode = mode;
    },
    checkPhoneNumber() {
      const phoneReg = /^1[3-9]\d{9}$/;
      if (phoneReg.test(this.phoneNumber)) {
        this.isPhoneNumberValid = true;
      } else {
        this.isPhoneNumberValid = false;
      }
    },
    goToVerifyCode() {
      const phoneReg = /^1[3-9]\d{9}$/;
      if (phoneReg.test(this.phoneNumber)) {
        this.loginMode = 'verify-code-login';
      } else {
        uni.showToast({
          title: '请输入正确的手机号码',
          icon: 'none'
        });
      }
    },
    getVerifyCode() {
      if (this.countdown > 0) {
        return; // 如果倒计时还没结束，直接返回，不重复获取验证码
      }
      const phoneReg = /^1[3-9]\d{9}$/;
      if (!phoneReg.test(this.phoneNumber)) {
        uni.showToast({
          title: '请输入正确的手机号码',
          icon: 'none'
        });
        return;
      }
      // 模拟发送请求到后端获取验证码，实际应用中替换下面的接口地址以及处理真实返回结果
      uni.request({
        url: 'https://your-api-url/getVerifyCode', // 替换为真实的获取验证码接口地址
        method: 'POST',
        data: {
          phoneNumber: this.phoneNumber
        },
        success: (res) => {
          if (res.data.code === 0) {
            // 假设后端返回code为0表示获取验证码成功
            uni.showToast({
              title: '验证码已发送，请注意查收',
              icon: 'success'
            });
            this.startCountdown(); // 开始倒计时
          } else {
            uni.showToast({
              title: res.data.message || '获取验证码失败，请稍后再试',
              icon: 'none'
            });
          }
        },
        fail: (err) => {
          uni.showToast({
            title: '网络请求失败，请检查网络',
            icon: 'none'
          });
        }
      });
    },
    startCountdown() {
      this.countdown = 60; // 设置倒计时总时长，这里设为60秒
      this.timer = setInterval(() => {
        if (this.countdown > 0) {
          this.countdown--;
        } else {
          clearInterval(this.timer); // 倒计时结束，清除定时器
        }
      }, 1000);
    },
    loginWithVerifyCode() {
      // 模拟发送请求到后端验证验证码进行登录，实际应用中替换下面的接口地址以及处理真实返回结果
      uni.request({
        url: 'https://your-api-url/loginWithVerifyCode', // 替换为真实的验证码登录接口地址
        method: 'POST',
        data: {
          phoneNumber: this.phoneNumber,
          verifyCode: this.verifyCode
        },
        success: (res) => {
          if (res.data.code === 0) {
            // 假设后端返回code为0表示登录成功
            uni.showToast({
              title: '登录成功',
              icon: 'success'
            });
            // 这里可以添加登录成功后的页面跳转等其他逻辑，比如跳转到聊天主界面
            uni.navigateTo({
              url: '/pages/chat/chat' // 替换为实际的聊天页面路径
            });
          } else {
            uni.showToast({
              title: res.data.message || '验证码错误，请重新输入',
              icon: 'none'
            });
          }
        },
        fail: (err) => {
          uni.showToast({
            title: '网络请求失败，请检查网络',
            icon: 'none'
          });
        }
      });
    },
    loginWithPassword() {
      // 实现使用密码登录的逻辑
      console.log('使用密码登录');
    }
  }
}
</script>

<style lang="scss" >
  .back-img{
    width: 100%;
    height: 100%;
    position: absolute;
    z-index: -10;
  }
	.container {
	  display: flex;
	  flex-direction: column;
	  align-items:center;
	}
	
	.header {
	  width: 100%;
	  display: flex;
	  justify-content: flex-end;
	  padding: 10px;
	}
	
	.help-feedback {
	  color: white;
	}
	
	.logo-area {
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  margin-top: 30px;
	}
	
	.logo {
	  width: 100px;
	  height: 100px;
	}
	
	.slogan {
	  color: white;
	  margin-top: 10px;
	}
	
	/* 本机号码一键登录模块样式 */
	.phone-number {
    
	  color: white;
	  margin-bottom: 10px;
	}
	
	.one-key-login {
	  width: 200px;
	  height: 40px;
	  background-color: black;
	  color: white;
	  border-radius: 5px;
	  margin-bottom: 10px;
	}
	
	.other-login {
	  width: 200px;
	  height: 40px;
	  background-color: orange;
	  color: white;
	  border-radius: 5px;
	}
	
	/* 其他手机号码登录模块样式 */
	/* 其他手机号码登录模块样式 */
	.input-area {
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  margin-top: 30px;
	}
	
	.code-input {
	  display: flex;
	  align-items: center;
	  border: 1px solid white;
	  border-radius: 5px;
	  width: 200px;
	  height: 40px;
	  margin-bottom: 10px;
    background-color: white;
	}
	
	.code {
	  color: black;
	  padding-left: 10px;
    width: 40px;
	}
	
	.continue-btn-disabled {
	  width: 200px;
	  height: 40px;
	  background-color: gray;
	  color: white;
	  border-radius: 5px;
	  pointer-events: none; // 禁用鼠标事件，让按钮不可点击时有相应的视觉反馈
	}
	
	.continue-btn {
	  width: 200px;
	  height: 40px;
	  background-color: black;
	  color: white;
	  border-radius: 5px;
	}
	
	/* 验证码登录模块样式 */
	.verify-code-area {
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  margin-top: 30px;
	}
	.input-button-row {
	display: flex;
	align-items: center;
  padding-left: 5px;
	width: 200px;
	justify-content: space-between;
  background-color: white;
   border-radius: 10px;
   height: 40px;
   font-size: 13px;
	}
	.greeting {
	  color: white;
	  margin-bottom: 10px;
	}
	
	.get-code-btn {
    font-size: 10px;
	 width: 100px;
	 height: 20px;
	 border: 1px solid #ccc;
	 border-radius: 5px;
	 background-color: white;
	 padding-bottom: 30px;
   background-color: black;
   color: white;
   
	}
	
	.login-btn {
	  width: 200px;
	  height: 40px;
	  background-color: gray;
	  color: white;
	  border-radius: 5px;
	}
	
	/* 密码登录模块样式 */
	.password-area {
	  display: flex;
	  flex-direction: column;
	  align-items: center;
	  margin-top: 30px;
	}
	
	.login-btn-password {
	  width: 200px;
	  height: 40px;
	  background-color: gray;
	  color: white;
	  border-radius: 10px;
	}
	
	/* 卡通区域样式（假设卡通元素为图片） */
	.cartoon-area {
	  position: absolute;
	  bottom: 0;
	  width: 100%;
	  display: flex;
	  justify-content: space-around;
	}
	
	.cartoon-element {
	  width: 80px;
	  height: 80px;
	}

</style>

