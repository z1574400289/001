<template>
	<view class="content">
		<view class="top-bar">
			<view class="top-bar-left" @tap="backOne">
				<image src="../../static/images/common/back.png" class="back-img"></image>
			</view>
			<view class="top-bar-center ">
				<view class="title">详情</view>
				</view>
			<view class="top-bar-right pice"></view>
	</view>
	<view class="main">
		<view class="column heads">
			<view class="row head">
				<view class="title">头像</view>
				<view class="content">
		<image-cropper :src="tempFilePath" @confirm="confirm" @cancel="cancel"></image-cropper>
		<image :src="cropFilePath" @tap="upload" class="user-img"></image>
				</view>
				<view class="more">
					<image src="../../static/images/userdetail/zuo.png"></image>
				</view>
			</view>
			<view class="row " @tap="modify">
				<view class="title">签名</view>
				<view class="content">
					看没看懂阿凡达，的局啊地卡斯蒂略噩66666666666
				</view>
				<view class="more">
					<image src="../../static/images/userdetail/zuo.png"></image>
				</view>
			</view>
			<view class="row ">
				<view class="title">注册</view>
				<view class="content">
					2019-12-22 13:32:45
				</view>
			</view>
			
			
		</view>
		<view class="column heads">
			<view class="row ">
				<view class="title">昵称</view>
				<view class="content">
					看阿凡达
				</view>
				<view class="more">
					<image src="../../static/images/userdetail/zuo.png"></image>
				</view>
			</view>
			<view class="row ">
				<view class="title">性别</view>
				<view class="content">
					<picker @change="bindPickerChange" :value="index" :range="array">
											<view class="uni-input">{{array[index]}}</view>
										</picker>
				</view>
				<view class="more">
					<image src="../../static/images/userdetail/左去@2x.png"></image>
				</view>
			</view>
			<view class="row ">
				<view class="title">生日</view>
				<view class="content">
				<picker mode="date" :value="date" :start="startDate" :end="endDate" @change="bindDateChange">
										<view class="uni-input">{{date}}</view>
									</picker>
				</view>
				<view class="more">
					<image src="../../static/images/userdetail/左去@2x.png"></image>
				</view>
			</view>
			<view class="row ">
				<view class="title">电话</view>
				<view class="content">
					16933559874
				</view>
				<view class="more">
					<image src="../../static/images/userdetail/左去@2x.png"></image>
				</view>
			</view>
			<view class="row ">
				<view class="title">邮箱</view>
				<view class="content">
					15699988877@qq.com
				</view>
				<view class="more">
					<image src="../../static/images/userdetail/左去@2x.png"></image>
				</view>
			</view>
		</view>
		<view class="column">
			<view class="row ">
				<view class="title">密码</view>
				<view class="content" style="password">
					*******
				</view>
				<view class="more">
					<image src="../../static/images/userdetail/zuo.png"></image>
				</view>
			</view>	
		</view>
		<view class="bt2">退出登录</view>
		<view class="modify" :style="{bottom:'-'+widHeight+'px'}" :animation="animationData" >
			<view class="modify-head">
				<view class="close" @tap="modify">取消</view>
				<view class="title">签名</view>
				<view class="define" @tap="modifyConfirm">确定</view>
			</view>
			<view class="modify-main">
				<input type="text" v-model="pwd" class="modify-pwd" placeholder="现密码" placeholder-style="color:#aaa;font-weight:4000"></input>
				<textarea v-model="data" class="modify-content"></textarea>
			</view>
		</view>
	</view>
	
	</view>
</template>

<script>
	import ImageCropper from "../../uni_modules/ling-imgcropper/components/ling-imgcropper/ling-imgcropper.vue";
	export default {
		
		data() {
			 const currentDate = this.getDate({
			            format: true,
						
			        })
			return {
				array: ['男', '女'],
				index:0,
				date: currentDate,
				tempFilePath: '',
				cropFilePath: '../../static/images/img/001.jpg',
				heading:'',
				data:'修改的内容',   		//修改内容
				isModify:false,            //动画打开判断值
				animationData: {},           //动画
				widHeight:''  ,          //页面高度
				pwd:'', 					//原密码
			}
		},
	components: {ImageCropper},
			computed: {
					startDate() {
						return this.getDate('start');
					},
					endDate() {
						return this.getDate('end');
					}
				},
	onReady:function() {
		this.getElementStyle();
	},
		methods: {
			//返回上一页
			backOne: function(){
				uni.navigateBack({
					delta: 1
				});
				},
				//性别选择器
			bindPickerChange: function(e) {
			            console.log('picker发送选择改变，携带值为', e.detail.value)
			            this.index = e.detail.value
			        },
					//日期选择器

			bindDateChange: function(e) {
			            this.date = e.detail.value
			        },
					//获取日期
		 getDate(type){
		            const date = new Date();
		            let year = date.getFullYear();
		            let month = date.getMonth() + 1;
		            let day = date.getDate();
		
		            if (type === 'start') {
		                year = year - 60;
		            } else if (type === 'end') {
		                year = year + 2;
		            }
		            month = month > 9 ? month : '0' + month;
		            day = day > 9 ? day : '0' + day;
		            return `${year}-${month}-${day}`;
		        },
				//头像裁剪
				  upload() {
				            uni.chooseImage({
				                count: 1, //默认9
				                sizeType: ['original', 'compressed'], //可以指定是原图还是压缩图，默认二者都有
				                sourceType: ['album','camera'], //从相册选择
				                success: (res) => {
				                    this.tempFilePath = res.tempFilePaths.shift()
				                }
				            });
				        },
				        confirm(e) {
				            this.tempFilePath = ''
				            this.cropFilePath = e.detail.tempFilePath
						// 	this.heading=e.detail.temFilePath;
							
						
						// 	uni.uploadFile({url:'后端上传图片接口地址',
						// 	filePath: this.heading,
						// 		name:'file',
						// 		fileType'image',
						// 		//formData:{},传递参数
						// 		success: (uploadFileRes) => {
						// 			var backstr= uploadFileRes.data;
						// 		},
						// 		complete() {
						// 			// console.log("this is heading"+this.heading )
						// 		},
						// 		fail(e) {
						// 			console.log("this is errormes"+e.message )
						// 		}
						// 	});
				        },
				        cancel() {
				            console.log('canceled')
							// this.tempFilePath="";
				        },
	//获取手机页面高度
	getElementStyle: function(){
		const query = uni.createSelectorQuery().in(this);
		query.select('.modify').boundingClientRect((data) => {
			this.widHeight = data.height;
			console.log('高度'+ this.widHeight);
		  }).exec();
	},
	//修改弹窗
	modify:function(){
		this.isModify=!this.isModify;
		var animation = uni.createAnimation({
		        duration: 300,
		        timingFunction: 'ease',
		    })
	
		     // this.animation = animation
			 if(this.isModify){
				 animation.bottom(0).step()
				 
			 }else{
				 animation.bottom(-this.widHeight ).step()
			 }
		    
		    this.animationData = animation.export()
	},
	//弹窗修改确定
	modifyConfirm:function(){
		this.modify();
	}
				
		}
	}
</script>

<style lang="scss">
@import "../../commons/css/mycss.scss";
.top-bar{
	background: rgba(255, 255, 255, 0.96);
	border-bottom: 1px solid $uni-border-color;
}
.main{
	padding-top: 118rpx;
	display: flex;
	flex-direction: column;
	.column{
		display: flex;
		flex-direction: column;
		padding-top: 12rpx;
		border-bottom: 1px solid $uni-border-color;
		.row{
			display: flex;
			flex-direction: row;	
		}
		.head{
			height: 148rpx;
			display: flex;
			align-items: center;
		}
		.title{
			flex: none;
			padding: 0 $uni-spacing-col-base;
			font-size: $uni-font-size-lg;
			color: $uni-text-color;
			line-height: 112rpx;
		}
		.content{
			flex: auto;
			// padding-left: $uni-spacing-col-base;
			font-size: $uni-font-size-lg;
			color: $uni-text-color-grey;
			line-height: 112rpx;
			overflow:hidden;
			white-space: nowrap;
			text-overflow: ellipsis;
			-o-text-overflow:ellipsis;
		}
		.user-img{
			// margin-top: -40rpx;
			width: $uni-img-size-lg;
			height: $uni-img-size-lg;
			border-radius: $uni-border-radius-base;
			display: flex;
			align-items: center;
		}
		
		.more{
		flex: none;
		height: 112rpx;
		display: flex;
		align-items: center;
		image{
			padding-right: 26rpx;
			width: 28rpx;
			height: 28rpx;
		}

		}
	}
}
.bt2{
	margin-top: 160rpx;
	text-align: center;
    line-height: 44rpx;
	color: $uni-color-error;	
	font-size:$uni-font-size-lg;
	
}
/*修改弹窗*/
.modify{
	position: fixed;
	z-index: 1002;
	left: 0;
	height: 100%;
	width: 100%;
	background-color: #fff;
	
	.modify-head{
		border-bottom: 1px solid $uni-border-color;
		width: 100%;
		height: 88rpx;
		display: flex;
		flex-direction: row;
		align-items: center;
		.close{
			line-height: 44rpx;
			padding-left: 32rpx;
			font-size:$uni-font-size-lg ;
			color: $uni-text-color;
		}
		.title{
			flex: auto;
			text-align: center;
			line-height: 44rpx;
			font-size:40rpx ;
			color: $uni-text-color;
		}
		.define{
			padding-right: 32rpx;
			line-height: 44rpx;
			font-size:$uni-font-size-lg ;
			color: $uni-color-success;
		}
	}
.modify-main{
	padding: 32rpx 12rpx 0 12rpx;
	.modify-pwd{
		padding-left: 22rpx;
		margin-bottom: $uni-border-radius-base;
		height: 88rpx;
		background: $uni-bg-color-grey;
		border-radius: $uni-border-radius-base;
		line-height: 88rpx;
		font-size: $uni-font-size-lg;
		color: $uni-text-color;
	}
	.modify-content{
		
		padding: 18rpx 22rpx;
		box-sizing: border-box;
		width: 100%;
		height: 386rpx;
		background: $uni-bg-color-grey;
		border-radius: $uni-border-radius-base;
		line-height: 44rpx;
		font-size: $uni-font-size-lg;
		color: $uni-text-color;
	}
	
}
}
</style>
