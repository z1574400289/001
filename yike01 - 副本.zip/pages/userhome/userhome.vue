<template>
	<view class="content">
		<view class="top-bar">
			<view class="top-bar-left" @tap="backOne">
				<image src="../../static/images/common/back.png" class="back-img"></image>
			</view>
			<view class="top-bar-right">
				<view class="more-img">
				<image src="../../static/images/userhome/more@2x.png" ></image>
			</view>
			</view>
		</view>
		<view class="bg">
			<view class="bg-bai"></view>
			<image src="../../static/images/img/003.jpg" mode="aspectFill" class="bg-img"> </image>
		</view>
		<view class="main">
			<view class="user-header" >
				<view class="sex" :style="{background:sexBg}" :animation="animationData3" >
					<image src="../../static/images/userhome/woman.png"></image>
				</view>
				<image :animation="animationData2" src="../../static/images/img/003.jpg" mode="aspectFill" class="user-img"> </image>
			</view>
			<view class="user-imf">
				<view class="name">{{user.name}}</view>
				<view class="nick">昵称：{{user.nick}}</view>
				<view class="intro">{{user.intr}}</view>
			</view>
		</view>
		<view class="bottom-bar">
			<view class="bottom-btn" @tap="addFriendAnimat">加好友</view>
		</view>
		<view class="add-misg" :style="{height:addHeight +'px',bottom:'-'+addHeight+'px'}" :animation="animationData" >
			<view class="name">{{user.name}}</view>
			<textarea :value="myname+'请求加为好友~'" maxlength="120" class="add-main"></textarea>
		</view>
		<view class="add-bt":animation="animationData1" >
			<view class="close" @tap="addFriendAnimat">取消</view>
			<view class="send">发送</view>
		</view>
		
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				addHeight:'',                //add板块高度
				sexBg:'rgba(255,93,91,1)',   //性别颜色
				myname:'春雨',             
				animationData: {},           //动画
				animationData1: {},           //动画
				animationData2: {},           //动画
				animationData3: {},           //动画
				isAdd:false,
				user:{                       //测试用户信息
					name:'秋风',
					nick:'秋之国',
					intr:'夜，结束了一天的喧嚣后安静下来，伴随着远处路灯那微弱的光。风，毫无预兆地席卷整片旷野，撩动人的思绪万千。',
				}
			};
		},
		onReady: function() {
			this.getElementStyle();
		},
		methods: {
			//返回上一页
			backOne: function(){
				uni.navigateBack({
					delta: 1
				});
			},
			//获取手机页面高度
			getElementStyle: function(){
				const query = uni.createSelectorQuery().in(this);
				query.select('.bg').boundingClientRect((data) => {
				    console.log("得到布局位置信息" + JSON.stringify(data));
				    console.log("节点离页面顶部的距离为" + data.top);
					this.addHeight = data.height-186;
				  }).exec();
			},
			//添加好友动画
			addFriendAnimat:function(){
				this.isAdd=!this.isAdd;
				var animation = uni.createAnimation({
				        duration: 300,
				        timingFunction: 'ease',
				    })
				var animation1 = uni.createAnimation({
				        duration: 300,
				        timingFunction: 'ease',
				    })
				var animation2 = uni.createAnimation({
				        duration: 300,
				        timingFunction: 'ease',
				    })
				var animation3 = uni.createAnimation({
				        duration: 300,
				        timingFunction: 'ease',
				    })
				     // this.animation = animation
					 if(this.isAdd){
						 animation.bottom(0).step()
						 animation1.bottom(0).step()
						 animation2.width(120).height(120).left(-120).top(40).step()
						 animation3.opacity(0).step()
					 }else{
						 animation.bottom(-this.addHeight).step()
						 animation1.bottom(-100).step()
						 animation2.width(200).height(200).left(0).top(0).step()
						 animation3.opacity(1).step()
					 }
				    
				    this.animationData = animation.export()
					this.animationData1 = animation1.export()
					this.animationData2 = animation2.export()
					this.animationData3 = animation3.export()
				
				    
			},
			
		}
	}
</script>

<style lang="scss">
  @import "../../commons/css/mycss.scss";
  .bg{
	  position: fixed;
	  top: 0;
	  left: 0;
	  z-index: -2;
	  width: 100%;
	  height: 100%;
	  .bg-bai{
		  width: 100%;
		  height: 100%;
		  //background-color: #eee;
	  }
	  .bg-img{
		  opacity: 0.4;
		  position: absolute;
		  left: -25rpx;
		  top:-10rpx;
		  z-index: -1;
		  width: 110%;
		  height: 110%;
		  filter: blur(16rpx);
	  }
	  
  } 
.main{
	text-align: center;
	padding-top: 148rpx;
	.user-header{
		margin: 0 auto;
		width: 412rpx;
		height: 412rpx;
		position: relative;
		.sex{
			z-index: 11;
			position: absolute;
			bottom: 22rpx;
			right: 22rpx;
			width: 64rpx;
			height: 64rpx;
			//background: $uni-color-error;
			border-radius:$uni-border-radius-circle;
		image{
			padding: 16rpx;
			width: 32rpx;
			height: 32rpx;
		}
		}
		.user-img{
			z-index:10;
			top: 0;
			left: 0;
			width: 400rpx;
			height: 400rpx;
			border: 6rpx solid #FFFFFF;
			border-radius: 48rpx;
		    box-shadow: 0px 36rpx 40rpx 0px rgba(39,40,50,0.1);
		}
	}
	.user-imf{
		.name{
			height: 74rpx;
			font-size: 52rpx;
			color: $uni-text-color;
		}
		.nick{
			height: 40rpx;
			font-size: $uni-font-size-base;
			color: $uni-text-color;
		}
		.intro{
		padding: 20rpx 120rpx;
		font-size: 28rpx;
		color: $uni-text-color;
		line-height: 48rpx;
		}
	}
	
}
.bottom-bar{
	position: fixed;
	bottom: 0rpx;
    width: 100%;  
	height: 104rpx;
	box-sizing: border-box;
	padding: 12rpx $uni-spacing-col-base;
	.bottom-btn{
		text-align: center;
		line-height: 80rpx;
		font-size: $uni-font-size-lg;
		color: $uni-text-color;
		width: 684rpx;
		height:80rpx;
		background: $uni-color-primary;
		border-radius: $uni-border-radius-sm;
	}

}
.add-misg{
	position: fixed;
	// bottom: 0;
	width: 100%;
	height: 1252rpx;
	padding: 0 56rpx;
	background: $uni-bg-color;
	border-radius: 40rpx 40rpx 0px 0px;
	box-sizing: border-box;
	.name{
		padding: 168rpx 0 40rpx 0;
		line-height: 74rpx;
		font-size: 52rpx;
		color: $uni-text-color;
	}
	.add-main{
		padding: 18rpx 22rpx;
		box-sizing: border-box;
		width: 100%;
		height: 420rpx;
		background: $uni-bg-color-grey;
		border-radius: $uni-border-radius-base;
		line-height: 44rpx;
		font-size: $uni-font-size-lg;
		color: $uni-text-color;
	}

}
.add-bt{
 position: fixed;
 bottom: -104rpx;
 width: 100%;  
 height: 104rpx;
 box-sizing: border-box;
 padding: 12rpx $uni-spacing-col-base;
 z-index: 100;
 display: flex;
	.close{
		flex: auto;
		width: 172rpx;
		height: 80rpx;
		background: $uni-bg-color-grey;
		text-align: center;
		line-height: 80rpx;
		border-radius: $uni-border-radius-sm;
	}
    .send{
		margin-left: $uni-spacing-col-base;
		flex: auto;
		text-align: center;
		line-height: 80rpx;
		font-size: $uni-font-size-lg;
		width: 480rpx;
		height:80rpx;
		background: $uni-color-primary;
		border-radius: $uni-border-radius-sm;
  	}
		
	}
</style>
