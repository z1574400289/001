<template>
  <view class="square-page">
    <view class="share-section">
      <share-item
        v-for="(share, index) in shareList"
        :key="index"
        :shareData="share"
      />
    </view>
    <view class="science-section">
      <text class="science-title">日常科普信息</text>
      <view class="science-content">
        <text v-for="(info, index) in scienceInfoList" :key="index">
          {{ info }}
        </text>
      </view>
    </view>
  </view>
</template>

<script>
import ShareItem from '@/components/share-item.vue';
export default {
  components: {
    ShareItem
  },
  data() {
    return {
      shareList: [
        {
          content: '今天去爬山了，风景真美呀！',
          likes: 0,
          comments: [],
          shareCount: 0
        },
        {
          content: '尝试做了新的美食，味道超棒！',
          likes: 0,
          comments: [],
          shareCount: 0
        }
      ], // 模拟分享列表数据
      scienceInfoList: [
        '多喝水有助于身体健康哦。',
        '每天适量运动可以提升免疫力。'
      ] // 模拟科普信息列表数据
    };
  }
};
</script>

<style lang="scss">
.square-page {
  display: flex;
  flex-direction: column;
  padding: 20px;

.share-section {
    margin-bottom: 20px;

    &:last-child {
      margin-bottom: 0;
    }
  }

.science-section {
    border-top: 1px solid #ccc;
    padding-top: 20px;

  .science-title {
      font-size: 20px;
      margin-bottom: 10px;
    }

  .science-content {
      text-align: left;
    }
  }
}
</style>