module.exports = {
       devServer: {
           proxy: {
               '/api': {
                   target: 'http://www.ceshi.com:8000',//这里替换为你的后端服务器地址
                   changeOrigin: true,
                   pathRewrite: {
                       '^/api': ''
                   }
               }
           }
       }
   };